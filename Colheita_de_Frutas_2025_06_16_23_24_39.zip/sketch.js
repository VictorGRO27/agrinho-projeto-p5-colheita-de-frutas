let maça = "🍎";
let uva = "🍇";
let abacaxi = "🍍";
let melancia = "🍉";
let limao = "🍋";
let mao = "🤲";
let x = 394;
let y = 721;
let x1 = 50;
let y1 = -25;
let x2 = 200;
let y2 = -25;
let x3 = 350;
let y3 = -25;
let x4 = 500;
let y4 = -25;
let x5 = 650;
let y5 = -25;
let veloc = 5;
let pontos = 0;
let somPontos;

function preload() {
  somPontos = loadSound("sound5.mp3");
}

function setup() {
  createCanvas(800, 800);
}

function draw() {
  gameplay();
  movimento();
}
function gameplay() {
  background("lightgreen");
  fill("rgb(158,231,255)");
  stroke("rgb(36,36,83)");
  strokeWeight(4);
  textFont("Arial Black");
  textSize(20);
  text("Pontuação:" + pontos, 20, 20);
  strokeWeight(1);
  stroke("black");
  fill("white");
  rect(0, 720, 800, 10);
  fill("black");
  rect(40, 720, 10, 10);
  rect(90, 720, 10, 10);
  rect(140, 720, 10, 10);
  rect(190, 720, 10, 10);
  rect(240, 720, 10, 10);
  rect(290, 720, 10, 10);
  rect(340, 720, 10, 10);
  rect(390, 720, 10, 10);
  rect(440, 720, 10, 10);
  rect(490, 720, 10, 10);
  rect(540, 720, 10, 10);
  rect(590, 720, 10, 10);
  rect(640, 720, 10, 10);
  rect(690, 720, 10, 10);
  rect(740, 720, 10, 10);
  textSize(40);
  text(maça, x1, y1);
  text(uva, x2, y2);
  text(abacaxi, x3, y3);
  text(melancia, x4, y4);
  text(limao, x5, y5);
  text(mao, x, y);
  if (mouseIsPressed) {
    console.log(mouseX, mouseY);
  }
}
function movimento() {
  if (keyIsDown(65)) {
    x -= 10;
  }
  if (keyIsDown(68)) {
    x += 10;
  }
  y1 += random(veloc);
  if (y1 > 80) {
    y2 += random(veloc);
  }
  if (y2 > 80) {
    y3 += random(veloc);
  }
  if (y3 > 80) {
    y4 += random(veloc);
  }
  if (y4 > 80) {
    y5 += random(veloc);
  }

  if (y1 > 745) {
    noLoop();
  }
  if (y2 > 745) {
    noLoop();
  }
  if (y3 > 745) {
    noLoop();
  }
  if (y4 > 745) {
    noLoop();
  }
  if (y5 > 745) {
    noLoop();
  }
  if (dist(x, y, x1, y1) < 40) {
    somPontos.play();
    pontos++;
    y1 = -25;
  }

  if (dist(x, y, x2, y2) < 40) {
    somPontos.play();
    pontos++;
    y2 = -25;
  }

  if (dist(x, y, x3, y3) < 40) {
    somPontos.play();
    pontos++;
    y3 = -25;
  }

  if (dist(x, y, x4, y4) < 40) {
    somPontos.play();
    pontos++;
    y4 = -25;
  }

  if (dist(x, y, x5, y5) < 40) {
    somPontos.play();
    pontos++;
    y5 = -25;
  }
}
